# Canvas Paint by Tracing

A Pen created on CodePen.io. Original URL: [https://codepen.io/harshsodi/pen/VwqxzZB](https://codepen.io/harshsodi/pen/VwqxzZB).

Using canvas, some javascript, and a draw loop to generate an interactive background; #codevember - 10/8/16